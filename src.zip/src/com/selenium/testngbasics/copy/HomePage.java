package com.selenium.testngbasics.copy;

import org.testng.annotations.Test;

public class HomePage 
{
	
	
	@Test(groups={"regression","Functional"})
	public void tc0012()
	{
		System.out.println("TC0012 is executed");
	}

}
