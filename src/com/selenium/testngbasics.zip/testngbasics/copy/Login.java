package com.selenium.testngbasics.copy;

import org.testng.annotations.Test;

public class Login 
{
	
	
	@Test
	public void tc008()
	{
		System.out.println("TC008 is executed");
	}

}
